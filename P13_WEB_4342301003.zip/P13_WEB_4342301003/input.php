<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form upload image</title>
</head>
<body>
    <Form action="proses-upload.php" method="POST" enctype="multipart/form-data">
        <table>
            <tr>
                <td>nis</td>
                <td><input type="text" name="nis" id="nis"></td>
            </tr>
            <tr>
                <td>nama</td>
                <td><input type="text" name="nama"id="nama"></td>
            </tr>
            <tr>
                <td>jenis kelamin</td>
                <td><input type="radio" name="jk"id="jk" value="laki-laki">laki laki
                <input type="radio" name="jk"id="jk" value="perempuan">perempuan</td>
            </tr>
            <tr>
                <td>alamat</td>
                <td><input type="text" name="alamat"id="alamat"></td>
                </tr>
                <tr>
                    <td>telepon</td>
                    <td><input type="text" name="telepon"id="telepon"></td>
                </tr>
                <tr>
                    <td>foto</td>
                    <td><input type="file" name="foto"id="foto"></td>
                </tr>
                <tr>
                    <td></td>
                    <td><input type="submit" value="upload"></td>
                </tr>
        </table>
    </Form>



</body>
</html>