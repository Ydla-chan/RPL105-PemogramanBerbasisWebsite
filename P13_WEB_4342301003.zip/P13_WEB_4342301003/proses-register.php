<?php
include 'koneksi.php';
$nama = $_POST['nama'];
$username = $_POST['username'];
$password = $_POST['password'];

$passacak = password_hash($password, PASSWORD_DEFAULT);
$input = mysqli_query($koneksi, "INSERT INTO user VALUES ('','$nama', '$username', '$passacak')");
if ($input) {
    echo "Registrasi Berhasil";
    header("location: login.php");
}else {
    echo "Registrasi Gagal";
}
?>