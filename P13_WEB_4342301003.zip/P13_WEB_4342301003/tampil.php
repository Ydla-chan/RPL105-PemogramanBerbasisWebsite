<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>menampilkan gambar</title>
</head>
<body>
    <table border="1">
        <tr>
            <th>No</th>
            <th>nis </th>
            <th>nama</th>
            <th>Jenis Kelamin</th>
            <th>alamat</th>
            <th>telepon</th>
            <th>foto</th>
        </tr>
</thead>
<tbody>
        <?php
        include 'koneksi.php';
        $query = mysqli_query($koneksi, "SELECT * FROM calon_mhs");
        $no = 1;
        while ($data = mysqli_fetch_array($query)) {
        ?>
            <tr>
                <td><?= $no++ ?></td>
                <td><?= $data['nis'] ?></td>
                <td><?= $data['nama'] ?></td>
                <td><?= $data['jk'] ?></td>
                <td><?= $data['alamat'] ?></td>
                <td><?= $data['telepon'] ?></td>
                <td><img src="C:/xampp/htdocs/image/<?= $data['foto'] ?>" width="100"></td>
            </tr>
        <?php
        }
?>
</tbody>
<tr><td><a href="laporan.php">Print Data</a></td></tr>
</table>

</body>
</html>