<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration</title>
</head>
<body>
    <form action="proses-register.php" method="POST">
        <label> Nama  </label>
        <input type="text" name="nama"> <br>
        <label> username </label>
        <input type="text" name="username"><br>
        <label> password </label>
        <input type="password" name="password">
        <input type="submit" value="Register">
</form>

    
</body>
</html>