<?php
include './fpdf/fpdf.php';
include 'koneksi.php';

$pdf = new FPDF("L","cm","A4");
$pdf->SetMargins(0.5,1,1);
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Arial','B',14);
$pdf->Cell(25.5,0.7,"DATA Jadwal",0,10,'C');
$pdf->ln();
$pdf->ln();

$pdf->Cell(2,0.8,'Kode ',1,0);
$pdf->Cell(8.9,0.8,'Mata kuliah ',1,0);
$pdf->Cell(7,0.8,'dosen Pengajar',1,0);
$pdf->Cell(4,0.8,'ruang',1,0);

$pdf->Cell(7,0.8,'Jam ',1,1);
$pdf->SetFont('Arial','',10);
$no = 1;
$tampil = mysqli_query($koneksi, "select * from jadwal");
while ($hasil = mysqli_fetch_array($tampil)){

    $pdf->Cell(2,0.8,$hasil['kode_matkul'],1,0);
    $pdf->Cell(8.9,0.8,$hasil['matkul'],1,0);
    $pdf->Cell(7,0.8,$hasil['dp'],1,0);
    $pdf->Cell(4,0.8,$hasil['ruang'],1,0);
  
    $pdf->Cell(7,0.8,$hasil['jam'],1,1);
    

    $no++;
}

$pdf->Output("laporan_mahasiswa.pdf","I");
?>