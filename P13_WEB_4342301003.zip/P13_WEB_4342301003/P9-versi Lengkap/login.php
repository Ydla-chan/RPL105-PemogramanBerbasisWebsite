<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="login.css">
    <title> Login</title>
</head>

<body>
    <div class="container">
        <div class="box form-box">
            <h2 align="center">Masuk</h2>
            <form method="POST" action="proses-login.php">
            <div class="field input">
                    <label for="username">Username</label>
                    <input type="text" name="username" id="username"  autocomplete="off" placeholder="masukkan Username" required>
                </div>
                <div class="field input">
                    <label for="password">Password</label>
                    <input type="password" name="password" id="password"  autocomplete="off" placeholder="masukkan Password" required>
                </div>
                <div class="field">
                    <input type="submit" class="btn" name="submit" value="Masuk" required>
                </div>

</body>

</form>
</div>
</div>

</html>