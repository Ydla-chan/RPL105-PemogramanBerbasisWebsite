<?php
session_start();

include("koneksi.php");

$username = $_POST['username'];
$password = $_POST['password'];

$data=mysqli_query($koneksi, "select * from user where username='$username'");
$row=mysqli_fetch_array($data);
if(password_verify($password, $row['pass'])){
 if(mysqli_num_rows($data)> 0){
    $_SESSION['username'] = $username;  
    header("location:index.php");
}else{
    header("location:login.php");
}
}
?>