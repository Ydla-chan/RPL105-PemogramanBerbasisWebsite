<?php

$host = "localhost";
$user = "admindyy";
$pass = "floald2731";
$db = "db_akademik";

$koneksi = mysqli_connect( $host, $user, $pass, $db ) or die( mysqli_error( $koneksi ) );