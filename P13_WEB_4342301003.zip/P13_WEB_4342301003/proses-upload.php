<?php
include 'koneksi.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

$nis = $_POST['nis'];
$nama = $_POST['nama'];
$jk = $_POST['jk'];
$alamat = $_POST['alamat'];
$telepon = $_POST['telepon'];

$foto = $_FILES['foto']['name'];
$ukuran_file = $_FILES['foto']['size'];
$x = explode('.', $foto);
$ekstensi = strtolower(end($x));
$ekstensi_diperbolehkan = array('jpg', 'png');
$temp = $_FILES['foto']['tmp_name'];

// Specify the full path for the destination directory
$upload_directory = 'C:/xampp/htdocs/image/';
$path = $upload_directory . $foto;

if (in_array($ekstensi, $ekstensi_diperbolehkan) === true) {
    if ($ukuran_file < 1000000) {
        if (!file_exists($upload_directory)) {
            mkdir($upload_directory, 0777, true); // Create the directory if it doesn't exist
        }

        if (move_uploaded_file($temp, $path)) {
            $query = $koneksi->prepare("INSERT INTO calon_mhs (nis, nama, jk, alamat, telepon, foto) VALUES (?, ?, ?, ?, ?, ?)");
            $query->bind_param("ssssss", $nis, $nama, $jk, $alamat, $telepon, $foto);
            $result = $query->execute();

            // Use header function to redirect
            if ($result) {
                header("Location: tampil.php");
                exit();
            } else {
                echo "terjadi kesalahan";
                echo "<br><a href='input.php'>Kembali</a>";
            }
        }
    }
}

?>
