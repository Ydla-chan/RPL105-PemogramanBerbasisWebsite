<?php
$host = "localhost";
$user = "admindyy";
$pass = "floald2731";
$db = "db_akademikmhs";
// melakukan koneksi ke db
$koneksi = mysqli_connect($host, $user, $pass, $db);
if (!$koneksi) {
    echo "Gagal konek: " . die(mysqli_error($koneksi));
}
?>